import logging
import os
import json
from openai import OpenAI

logger = logging.getLogger(__name__)

try:
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    if not os.getenv('OPENAI_API_KEY'):
        logger.error("OPENAI_API_KEY not found in environment variables")
        raise ValueError("OPENAI_API_KEY environment variable is required")
    logger.info("OpenAI client initialized successfully")
except Exception as e:
    logger.critical(f"Failed to initialize OpenAI client: {str(e)}", exc_info=True)
    raise

def extract_topics(discussion_text: str) -> list:
    logger.info("Extracting topics using OpenAI")
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a topic extraction specialist. Extract all relevant topics from the conversation. Return ONLY a JSON array of topic strings, nothing else. Example format: [\"topic1\", \"topic2\"]"},
                {"role": "user", "content": f"Extract all topics from this conversation:\n{discussion_text}"}
            ],
            temperature=0.3,
            max_tokens=150
        )
        response_text = response.choices[0].message.content.strip()
        topics = json.loads(response_text)
        return topics
    except Exception as e:
        logger.error(f"Error extracting topics: {str(e)}", exc_info=True)
        return []

def create_notification_prompt(messages: list, user_name="User", user_facts="", user_context="") -> dict:
    logger.info(f"Creating notification prompt for {len(messages)} messages")
    formatted_discussion = []
    for msg in messages:
        speaker = "{{user_name}}" if msg.get('is_user') else "other"
        formatted_discussion.append(f"{msg['text']} ({speaker})")
    discussion_text = "\n".join(formatted_discussion)
    topics = extract_topics(discussion_text)
    system_prompt = (
        "You are {user_name}'s personal AI mentor. Your FIRST task is to determine if this conversation warrants interruption.\n"
        "STEP 1 - Evaluate if ALL of these conditions are true:\n"
        "  • {user_name} is actively in the conversation.\n"
        "  • {user_name} expressed a clear problem, challenge, goal, or question.\n"
        "  • You have a specific recommendation that would likely help {user_name}.\n"
        "  • Your insight is time-sensitive and valuable enough to be sent immediately.\n"
        "If ANY condition isn't met, respond with an empty string \"\".\n"
        "STEP 2 - If met, respond with direct advice using simple words, under 300 characters, and end with a specific question inviting action.\n"
        "Here's what we know about {user_name}: {user_facts}\n\n"
        "Current discussion:\n{text}\n\n"
        "Previous context: {user_context}\n\n"
        "Your response:"
    ).format(user_name=user_name, user_facts=user_facts, user_context=user_context, text=discussion_text)
    
    notification = {
        "notification": {
            "prompt": system_prompt,
            "params": ["user_name", "user_facts", "user_context"],
            "context": {"filters": {"people": [], "entities": [], "topics": topics}}
        }
    }
    return notification