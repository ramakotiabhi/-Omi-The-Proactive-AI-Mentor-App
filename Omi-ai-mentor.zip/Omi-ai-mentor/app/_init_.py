
### 4. app/__init__.py

Initialize the Flask application.

```python
from flask import Flask
from app.routes import app_routes
import logging
import os
from datetime import datetime

app = Flask(__name__)
app.register_blueprint(app_routes)

os.environ["START_TIME"] = str(time.time())

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s')

if __name__ == '__main__':
    logging.info(f"Application initialized at {datetime.fromtimestamp(float(os.environ['START_TIME']))}")
    app.run(host='0.0.0.0', port=5010, debug=True)