import logging
import os
import time
import json
import threading
from collections import defaultdict

from flask import Blueprint, request, jsonify
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI
import requests

from app.utils import MessageBuffer, extract_topics, create_notification_prompt

env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

APP_ID = "01JFFC690S2B89MJYPPM5TTM1Q"
API_KEY = os.getenv("API_KEY", "your_notification_api_key")
REMINDER_MESSAGE = "Hey! How's it going with my previous suggestion? Have you had a chance to try it out?"
API_BASE_URL = os.getenv("API_BASE_URL", "https://api.yournotificationservice.com")

ANALYSIS_INTERVAL = 5
REMINDER_INTERVAL = 10
REMINDER_CHECK_INTERVAL = 2

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(levelname)s - [%(threadName)s] - %(module)s:%(lineno)d - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

try:
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    if not os.getenv('OPENAI_API_KEY'):
        logger.error("OPENAI_API_KEY not found in environment variables")
        raise ValueError("OPENAI_API_KEY environment variable is required")
    logger.info("OpenAI client initialized successfully")
except Exception as e:
    logger.critical(f"Failed to initialize OpenAI client: {str(e)}", exc_info=True)
    raise

app_routes = Blueprint('app_routes', __name__)

class MessageBuffer:
    def __init__(self):
        logger.info("Initializing MessageBuffer")
        self.buffers = {}
        self.lock = threading.Lock()
        self.cleanup_interval = 300
        self.last_cleanup = time.time()
        self.silence_threshold = 120
        self.min_words_after_silence = 5
        self.last_notification_times = defaultdict(dict)
        self.last_reminder_times = defaultdict(dict)
    
    def get_buffer(self, session_id):
        current_time = time.time()
        if current_time - self.last_cleanup > self.cleanup_interval:
            self.cleanup_old_sessions()
        with self.lock:
            if session_id not in self.buffers:
                self.buffers[session_id] = {
                    'messages': [],
                    'last_analysis_time': current_time,
                    'last_activity': current_time,
                    'words_after_silence': 0,
                    'silence_detected': False
                }
            else:
                time_since_activity = current_time - self.buffers[session_id]['last_activity']
                if time_since_activity > self.silence_threshold:
                    self.buffers[session_id]['silence_detected'] = True
                    self.buffers[session_id]['words_after_silence'] = 0
                    self.buffers[session_id]['messages'] = []
                self.buffers[session_id]['last_activity'] = current_time
        return self.buffers[session_id]
    
    def cleanup_old_sessions(self):
        current_time = time.time()
        with self.lock:
            expired_sessions = [sid for sid, data in self.buffers.items()
                                if current_time - data['last_activity'] > 3600]
            for sid in expired_sessions:
                del self.buffers[sid]
                if sid in self.last_notification_times:
                    del self.last_notification_times[sid]
                if sid in self.last_reminder_times:
                    del self.last_reminder_times[sid]
            self.last_cleanup = current_time
    
    def set_last_notification_time(self, session_id, message_id):
        with self.lock:
            self.last_notification_times[session_id][message_id] = time.time()
    
    def get_sessions_needing_reminder(self):
        current_time = time.time()
        messages_to_remind = []
        with self.lock:
            messages_to_remove = []
            for session_id, message_dict in self.last_notification_times.items():
                for message_id, last_time in message_dict.items():
                    last_reminder = self.last_reminder_times.get(session_id, {}).get(message_id, 0)
                    if current_time - last_time >= REMINDER_INTERVAL and last_reminder == 0:
                        messages_to_remind.append((session_id, message_id))
                        self.last_reminder_times[session_id][message_id] = current_time
                        messages_to_remove.append((session_id, message_id))
            for session_id, message_id in messages_to_remove:
                if message_id in self.last_notification_times[session_id]:
                    del self.last_notification_times[session_id][message_id]
                if not self.last_notification_times[session_id]:
                    del self.last_notification_times[session_id]
        return messages_to_remind

message_buffer = MessageBuffer()

def send_reminder_notification(session_id, message_id):
    logger.info(f"Sending reminder for session {session_id}, message {message_id}")
    notification_url = f"{API_BASE_URL.rstrip('/')}/v2/integrations/{APP_ID}/notification"
    headers = {'Authorization': f'Bearer {API_KEY}'}
    params = {"uid": session_id, "message": REMINDER_MESSAGE}
    try:
        response = requests.post(notification_url, headers=headers, params=params)
        if response.status_code == 200:
            logger.info(f"Reminder sent for session {session_id}, message {message_id}")
        else:
            logger.error(f"Reminder failed. Status: {response.status_code}, Response: {response.text}")
    except Exception as e:
        logger.error(f"Error sending reminder: {str(e)}", exc_info=True)

def reminder_check_loop():
    while True:
        try:
            msgs = message_buffer.get_sessions_needing_reminder()
            if msgs:
                for sid, mid in msgs:
                    send_reminder_notification(sid, mid)
        except Exception as e:
            logger.error(f"Error in reminder loop: {str(e)}", exc_info=True)
        time.sleep(REMINDER_CHECK_INTERVAL)

reminder_thread = threading.Thread(target=reminder_check_loop, daemon=True)
reminder_thread.start()

def extract_topics(discussion_text: str) -> list:
    logger.info("Extracting topics using OpenAI")
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a topic extraction specialist. Extract all relevant topics from the conversation. Return ONLY a JSON array of topic strings, nothing else. Example format: [\"topic1\", \"topic2\"]"},
                {"role": "user", "content": f"Extract all topics from this conversation:\n{discussion_text}"}
            ],
            temperature=0.3,
            max_tokens=150
        )
        response_text = response.choices[0].message.content.strip()
        topics = json.loads(response_text)
        return topics
    except Exception as e:
        logger.error(f"Error extracting topics: {str(e)}", exc_info=True)
        return []

def create_notification_prompt(messages: list, user_name="User", user_facts="", user_context="") -> dict:
    logger.info(f"Creating notification prompt for {len(messages)} messages")
    formatted_discussion = []
    for msg in messages:
        speaker = "{{user_name}}" if msg.get('is_user') else "other"
        formatted_discussion.append(f"{msg['text']} ({speaker})")
    discussion_text = "\n".join(formatted_discussion)
    topics = extract_topics(discussion_text)
    system_prompt = (
        "You are {user_name}'s personal AI mentor. Your FIRST task is to determine if this conversation warrants interruption.\n"
        "STEP 1 - Evaluate if ALL of these conditions are true:\n"
        "  • {user_name} is actively in the conversation.\n"
        "  • {user_name} expressed a clear problem, challenge, goal, or question.\n"
        "  • You have a specific recommendation that would likely help {user_name}.\n"
        "  • Your insight is time-sensitive and valuable enough to be sent immediately.\n"
        "If ANY condition isn't met, respond with an empty string \"\".\n"
        "STEP 2 - If met, respond with direct advice using simple words, under 300 characters, and end with a specific question inviting action.\n"
        "Here's what we know about {user_name}: {user_facts}\n\n"
        "Current discussion:\n{text}\n\n"
        "Previous context: {user_context}\n\n"
        "Your response:"
    ).format(user_name=user_name, user_facts=user_facts, user_context=user_context, text=discussion_text)
    
    notification = {
        "notification": {
            "prompt": system_prompt,
            "params": ["user_name", "user_facts", "user_context"],
            "context": {"filters": {"people": [], "entities": [], "topics": topics}}
        }
    }
    return notification

@app_routes.route('/webhook', methods=['POST'])
def webhook():
    logger.info("Received webhook POST")
    try:
        data = request.json
        session_id = data.get('session_id')
        segments = data.get('segments', [])
        message_id = data.get('message_id')
        if not message_id:
            message_id = f"{session_id}_{int(time.time())}"
        if not session_id:
            return jsonify({"message": "No session_id provided"}), 400
        current_time = time.time()
        buffer_data = message_buffer.get_buffer(session_id)
        for segment in segments:
            text = segment.get('text', '').strip()
            if text:
                timestamp = segment.get('start', current_time)
                is_user = segment.get('is_user', False)
                if buffer_data['silence_detected']:
                    words = len(text.split())
                    buffer_data['words_after_silence'] += words
                    if buffer_data['words_after_silence'] >= message_buffer.min_words_after_silence:
                        buffer_data['silence_detected'] = False
                        buffer_data['last_analysis_time'] = current_time
                can_append = (buffer_data['messages'] and
                              abs(buffer_data['messages'][-1]['timestamp'] - timestamp) < 2.0 and
                              buffer_data['messages'][-1].get('is_user') == is_user)
                if can_append:
                    buffer_data['messages'][-1]['text'] += " " + text
                else:
                    buffer_data['messages'].append({
                        'text': text,
                        'timestamp': timestamp,
                        'is_user': is_user
                    })
        if (current_time - buffer_data['last_analysis_time'] >= ANALYSIS_INTERVAL and 
            buffer_data['messages'] and not buffer_data['silence_detected']):
            sorted_messages = sorted(buffer_data['messages'], key=lambda x: x['timestamp'])
            user_context_data = get_user_context(session_id)
            user_name = user_context_data.get("user_name")
            user_facts = user_context_data.get("user_facts")
            user_context = user_context_data.get("user_context")
            notification = create_notification_prompt(
                sorted_messages, user_name=user_name, user_facts=user_facts, user_context=user_context
            )
            buffer_data['last_analysis_time'] = current_time
            buffer_data['messages'] = []
            message_buffer.set_last_notification_time(session_id, message_id)
            return jsonify(notification), 200
        return jsonify({}), 202
    except Exception as e:
        logger.error(f"Webhook error: {str(e)}", exc_info=True)
        return jsonify({"error": "Internal server error"}), 500

@app_routes.route('/webhook/setup-status', methods=['GET'])
def setup_status():
    return jsonify({"is_setup_completed": True}), 200

@app_routes.route('/status', methods=['GET'])
def status():
    uptime = time.time() - float(os.environ.get("START_TIME", time.time()))
    active_sessions = len(message_buffer.buffers)
    return jsonify({"active_sessions": active_sessions, "uptime": uptime}), 200

def get_user_context(session_id):
    """Retrieves user context based on the session ID.
    This is a placeholder. Replace with your actual logic
    to fetch user data (facts, previous discussions, goals, etc.).
    """
    user_data = {
        "user_name": "Nikita",
        "user_facts": "Software engineer, interested in AI, working on a challenging project.",
        "user_context": "Previous conversations about project deadlines, technical challenges, and work-life balance."
    }
    return user_data