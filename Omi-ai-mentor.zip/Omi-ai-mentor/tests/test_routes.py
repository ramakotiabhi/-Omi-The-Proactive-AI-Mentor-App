import unittest
import json
from app import app

class TestWebhook(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()

    def test_webhook_valid_data(self):
        valid_payload = {
            "session_id": "session1",
            "segments": [
                {"text": "I'm feeling really stressed about my upcoming presentation.", "is_user": True, "start": 1678886400},
                {"text": "It's a big one, I know. But you've prepared well.", "is_user": False, "start": 1678886460},
                {"text": "I'm still not sure if I've covered everything.", "is_user": True, "start": 1678886520}
            ]
        }
        response = self.app.post('/webhook', json=valid_payload)
        self.assertEqual(response.status_code, 200)

    def test_webhook_missing_session_id(self):
        invalid_payload = {
            "segments": [
                {"text": "I'm feeling really stressed about my upcoming presentation.", "is_user": True, "start": 1678886400}
            ]
        }
        response = self.app.post('/webhook', json=invalid_payload)
        self.assertEqual(response.status_code, 400)

if __name__ == '__main__':
    unittest.main()